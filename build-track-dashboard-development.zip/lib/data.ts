export type ProjectStatus = "in_arbeit" | "geplant" | "abgeschlossen" | "verzoegert"

export type Project = {
  id: string
  name: string
  client: string
  location: string
  status: ProjectStatus
  progress: number
  budget: number
  spent: number
  start: string
  end: string
  manager: string
}

export const projects: Project[] = [
  {
    id: "P-2041",
    name: "Wohnkomplex Lindenhof",
    client: "Stadtbau München GmbH",
    location: "München, Schwabing",
    status: "in_arbeit",
    progress: 62,
    budget: 4200000,
    spent: 2604000,
    start: "2025-11-04",
    end: "2026-09-30",
    manager: "Andreas Vogel",
  },
  {
    id: "P-2038",
    name: "Bürogebäude Rheinturm",
    client: "Rhein Invest AG",
    location: "Düsseldorf, Hafen",
    status: "in_arbeit",
    progress: 41,
    budget: 8750000,
    spent: 3587500,
    start: "2026-01-12",
    end: "2027-03-15",
    manager: "Sabine Krüger",
  },
  {
    id: "P-2033",
    name: "Kita Sonnenschein",
    client: "Gemeinde Ottobrunn",
    location: "Ottobrunn",
    status: "verzoegert",
    progress: 78,
    budget: 1950000,
    spent: 1638000,
    start: "2025-06-02",
    end: "2026-05-20",
    manager: "Andreas Vogel",
  },
  {
    id: "P-2029",
    name: "Sanierung Altbau Goethestraße",
    client: "Hausverwaltung Berger",
    location: "Augsburg",
    status: "geplant",
    progress: 8,
    budget: 720000,
    spent: 57600,
    start: "2026-04-01",
    end: "2026-12-10",
    manager: "Michael Braun",
  },
  {
    id: "P-2025",
    name: "Logistikzentrum Nord",
    client: "TransCargo Logistik",
    location: "Nürnberg",
    status: "abgeschlossen",
    progress: 100,
    budget: 6300000,
    spent: 6115000,
    start: "2024-09-15",
    end: "2025-12-18",
    manager: "Sabine Krüger",
  },
  {
    id: "P-2022",
    name: "Parkhaus Zentrum",
    client: "City Parking Solutions",
    location: "Regensburg",
    status: "in_arbeit",
    progress: 34,
    budget: 3100000,
    spent: 1054000,
    start: "2026-02-03",
    end: "2026-11-28",
    manager: "Michael Braun",
  },
]

export type Material = {
  id: string
  name: string
  category: string
  unit: string
  stock: number
  minStock: number
  price: number
  supplier: string
  location: string
}

export const materials: Material[] = [
  { id: "M-101", name: "Zement CEM I 42,5 R", category: "Bindemittel", unit: "Sack", stock: 240, minStock: 100, price: 6.9, supplier: "HeidelbergCement", location: "Lager München" },
  { id: "M-102", name: "Betonstahl B500B Ø12", category: "Stahl", unit: "t", stock: 4.2, minStock: 8, price: 890, supplier: "ArcelorMittal", location: "Lager München" },
  { id: "M-103", name: "Kalksandstein 24 cm", category: "Mauerwerk", unit: "Stk", stock: 3200, minStock: 1500, price: 1.35, supplier: "Xella", location: "Baustelle Lindenhof" },
  { id: "M-104", name: "Dämmplatte EPS 140 mm", category: "Dämmung", unit: "m²", stock: 85, minStock: 200, price: 18.5, supplier: "Sto SE", location: "Lager Düsseldorf" },
  { id: "M-105", name: "Estrichbeton CT-C25", category: "Beton", unit: "m³", stock: 12, minStock: 10, price: 118, supplier: "Cemex", location: "Baustelle Rheinturm" },
  { id: "M-106", name: "Gipskartonplatte 12,5 mm", category: "Trockenbau", unit: "Stk", stock: 46, minStock: 120, price: 8.2, supplier: "Knauf", location: "Lager München" },
  { id: "M-107", name: "Dachziegel Frankfurter Pfanne", category: "Dach", unit: "Stk", stock: 5400, minStock: 2000, price: 0.95, supplier: "Braas", location: "Lager Nürnberg" },
  { id: "M-108", name: "Bauholz KVH 60x120", category: "Holz", unit: "lfm", stock: 180, minStock: 250, price: 4.6, supplier: "Holz Schröder", location: "Lager Düsseldorf" },
  { id: "M-109", name: "Fliesenkleber flexibel", category: "Bauchemie", unit: "Sack", stock: 68, minStock: 40, price: 14.9, supplier: "Sopro", location: "Baustelle Kita" },
  { id: "M-110", name: "Kabel NYM-J 3x1,5", category: "Elektro", unit: "m", stock: 320, minStock: 500, price: 1.1, supplier: "Sonepar", location: "Lager München" },
]

export const lowStockMaterials = materials.filter((m) => m.stock < m.minStock)

export type Defect = {
  id: string
  title: string
  project: string
  trade: string
  severity: "kritisch" | "hoch" | "mittel" | "gering"
  status: "offen" | "in_bearbeitung" | "behoben"
  reportedBy: string
  reportedAt: string
  dueDate: string
}

export const defects: Defect[] = [
  { id: "MG-501", title: "Riss in tragender Wand EG", project: "Wohnkomplex Lindenhof", trade: "Rohbau", severity: "kritisch", status: "in_bearbeitung", reportedBy: "Andreas Vogel", reportedAt: "2026-09-08", dueDate: "2026-09-18" },
  { id: "MG-498", title: "Feuchtigkeit im Kellergeschoss", project: "Bürogebäude Rheinturm", trade: "Abdichtung", severity: "hoch", status: "offen", reportedBy: "Sabine Krüger", reportedAt: "2026-09-10", dueDate: "2026-09-22" },
  { id: "MG-495", title: "Fugen Fliesen unsauber Bad 2.OG", project: "Kita Sonnenschein", trade: "Fliesenleger", severity: "gering", status: "offen", reportedBy: "Michael Braun", reportedAt: "2026-09-11", dueDate: "2026-09-25" },
  { id: "MG-492", title: "Fehlende Brandschutzverkleidung", project: "Bürogebäude Rheinturm", trade: "Trockenbau", severity: "kritisch", status: "offen", reportedBy: "Sabine Krüger", reportedAt: "2026-09-12", dueDate: "2026-09-19" },
  { id: "MG-488", title: "Türblatt verzogen Raum 104", project: "Wohnkomplex Lindenhof", trade: "Tischler", severity: "mittel", status: "behoben", reportedBy: "Andreas Vogel", reportedAt: "2026-08-30", dueDate: "2026-09-10" },
  { id: "MG-483", title: "Elektroleitung nicht normgerecht", project: "Parkhaus Zentrum", trade: "Elektro", severity: "hoch", status: "in_bearbeitung", reportedBy: "Michael Braun", reportedAt: "2026-09-06", dueDate: "2026-09-20" },
  { id: "MG-479", title: "Farbabweichung Fassade Nordseite", project: "Kita Sonnenschein", trade: "Maler", severity: "gering", status: "behoben", reportedBy: "Michael Braun", reportedAt: "2026-08-25", dueDate: "2026-09-05" },
]

export type Task = {
  id: string
  title: string
  project: string
  assignee: string
  priority: "hoch" | "mittel" | "niedrig"
  status: "offen" | "in_arbeit" | "erledigt"
  dueDate: string
}

export const tasks: Task[] = [
  { id: "T-3012", title: "Bewehrungsabnahme Bodenplatte", project: "Bürogebäude Rheinturm", assignee: "Sabine Krüger", priority: "hoch", status: "offen", dueDate: "2026-09-17" },
  { id: "T-3010", title: "Materialbestellung Dämmung freigeben", project: "Wohnkomplex Lindenhof", assignee: "Andreas Vogel", priority: "hoch", status: "in_arbeit", dueDate: "2026-09-16" },
  { id: "T-3008", title: "Bautagebuch KW 38 abschließen", project: "Kita Sonnenschein", assignee: "Michael Braun", priority: "mittel", status: "offen", dueDate: "2026-09-19" },
  { id: "T-3005", title: "Kran-Wartung koordinieren", project: "Logistikzentrum Nord", assignee: "Petra Lang", priority: "mittel", status: "erledigt", dueDate: "2026-09-12" },
  { id: "T-3003", title: "Sicherheitsunterweisung neue Mitarbeiter", project: "Parkhaus Zentrum", assignee: "Thomas Wagner", priority: "hoch", status: "in_arbeit", dueDate: "2026-09-18" },
  { id: "T-3001", title: "Angebot Sanitärarbeiten einholen", project: "Sanierung Altbau Goethestraße", assignee: "Michael Braun", priority: "niedrig", status: "offen", dueDate: "2026-09-24" },
  { id: "T-2998", title: "Aufmaß Trockenbau 3.OG", project: "Bürogebäude Rheinturm", assignee: "Sabine Krüger", priority: "mittel", status: "offen", dueDate: "2026-09-20" },
]

export type DailyReport = {
  id: string
  date: string
  project: string
  author: string
  weather: string
  temperature: number
  workers: number
  hours: number
  summary: string
}

export const dailyReports: DailyReport[] = [
  { id: "BR-908", date: "2026-09-15", project: "Wohnkomplex Lindenhof", author: "Andreas Vogel", weather: "Bewölkt", temperature: 17, workers: 14, hours: 112, summary: "Betonage Decke über 2.OG abgeschlossen. Schalung für 3.OG begonnen." },
  { id: "BR-907", date: "2026-09-15", project: "Bürogebäude Rheinturm", author: "Sabine Krüger", weather: "Regen", temperature: 14, workers: 9, hours: 68, summary: "Abdichtungsarbeiten Kellergeschoss wegen Nässe unterbrochen. Materiallieferung eingetroffen." },
  { id: "BR-905", date: "2026-09-14", project: "Kita Sonnenschein", author: "Michael Braun", weather: "Sonnig", temperature: 21, workers: 6, hours: 48, summary: "Fliesenarbeiten in den Sanitärräumen fortgesetzt. Malerarbeiten Flur EG begonnen." },
  { id: "BR-903", date: "2026-09-14", project: "Parkhaus Zentrum", author: "Thomas Wagner", weather: "Heiter", temperature: 19, workers: 11, hours: 88, summary: "Stützen 1. Ebene geschalt und bewehrt. Elektroleerrohre verlegt." },
  { id: "BR-901", date: "2026-09-13", project: "Wohnkomplex Lindenhof", author: "Andreas Vogel", weather: "Bewölkt", temperature: 16, workers: 13, hours: 104, summary: "Mauerarbeiten Innenwände 2.OG. Anlieferung Kalksandstein verräumt." },
]

export type Employee = {
  id: string
  name: string
  role: string
  team: string
  phone: string
  email: string
  status: "verfügbar" | "auf_baustelle" | "urlaub" | "krank"
  project: string
}

export const employees: Employee[] = [
  { id: "E-01", name: "Andreas Vogel", role: "Bauleiter", team: "Bauleitung", phone: "+49 151 2345 6710", email: "a.vogel@buildtrack.de", status: "auf_baustelle", project: "Wohnkomplex Lindenhof" },
  { id: "E-02", name: "Sabine Krüger", role: "Bauleiterin", team: "Bauleitung", phone: "+49 151 2345 6711", email: "s.krueger@buildtrack.de", status: "auf_baustelle", project: "Bürogebäude Rheinturm" },
  { id: "E-03", name: "Michael Braun", role: "Polier", team: "Rohbau", phone: "+49 151 2345 6712", email: "m.braun@buildtrack.de", status: "auf_baustelle", project: "Kita Sonnenschein" },
  { id: "E-04", name: "Thomas Wagner", role: "Vorarbeiter", team: "Rohbau", phone: "+49 151 2345 6713", email: "t.wagner@buildtrack.de", status: "auf_baustelle", project: "Parkhaus Zentrum" },
  { id: "E-05", name: "Petra Lang", role: "Disponentin", team: "Logistik", phone: "+49 151 2345 6714", email: "p.lang@buildtrack.de", status: "verfügbar", project: "—" },
  { id: "E-06", name: "Jörg Fischer", role: "Maurer", team: "Rohbau", phone: "+49 151 2345 6715", email: "j.fischer@buildtrack.de", status: "auf_baustelle", project: "Wohnkomplex Lindenhof" },
  { id: "E-07", name: "Elena Popovic", role: "Elektrikerin", team: "Elektro", phone: "+49 151 2345 6716", email: "e.popovic@buildtrack.de", status: "urlaub", project: "—" },
  { id: "E-08", name: "Kurt Hoffmann", role: "Kranführer", team: "Logistik", phone: "+49 151 2345 6717", email: "k.hoffmann@buildtrack.de", status: "krank", project: "—" },
  { id: "E-09", name: "Nadine Schmitt", role: "Bauzeichnerin", team: "Planung", phone: "+49 151 2345 6718", email: "n.schmitt@buildtrack.de", status: "verfügbar", project: "Bürogebäude Rheinturm" },
]

export type Photo = {
  id: string
  title: string
  project: string
  date: string
  author: string
  src: string
}

export const photos: Photo[] = [
  { id: "F-01", title: "Rohbau 2.OG Betonage", project: "Wohnkomplex Lindenhof", date: "2026-09-15", author: "Andreas Vogel", src: "/photos/rohbau-betonage.png" },
  { id: "F-02", title: "Baustelleneinrichtung Kran", project: "Bürogebäude Rheinturm", date: "2026-09-14", author: "Sabine Krüger", src: "/photos/baustelle-kran.png" },
  { id: "F-03", title: "Fassade Fortschritt", project: "Kita Sonnenschein", date: "2026-09-13", author: "Michael Braun", src: "/photos/fassade-fortschritt.png" },
  { id: "F-04", title: "Bewehrung Bodenplatte", project: "Parkhaus Zentrum", date: "2026-09-12", author: "Thomas Wagner", src: "/photos/bewehrung-bodenplatte.png" },
  { id: "F-05", title: "Innenausbau Sanitär", project: "Kita Sonnenschein", date: "2026-09-11", author: "Michael Braun", src: "/photos/innenausbau-sanitaer.png" },
  { id: "F-06", title: "Materiallager Übersicht", project: "Wohnkomplex Lindenhof", date: "2026-09-10", author: "Petra Lang", src: "/photos/materiallager.png" },
]

export const kpis = {
  activeProjects: projects.filter((p) => p.status === "in_arbeit").length,
  openDefects: defects.filter((d) => d.status !== "behoben").length,
  openTasks: tasks.filter((t) => t.status !== "erledigt").length,
  lowStock: lowStockMaterials.length,
  workersToday: dailyReports.filter((r) => r.date === "2026-09-15").reduce((s, r) => s + r.workers, 0),
  totalBudget: projects.reduce((s, p) => s + p.budget, 0),
  totalSpent: projects.reduce((s, p) => s + p.spent, 0),
}

export const activityFeed = [
  { id: "a1", text: "Neuer Mangel MG-498 gemeldet – Feuchtigkeit Kellergeschoss", project: "Bürogebäude Rheinturm", time: "vor 2 Std.", type: "mangel" as const },
  { id: "a2", text: "Bautagebuch BR-908 eingereicht", project: "Wohnkomplex Lindenhof", time: "vor 3 Std.", type: "bericht" as const },
  { id: "a3", text: "Materialbestand kritisch: Dämmplatte EPS 140 mm", project: "Lager Düsseldorf", time: "vor 5 Std.", type: "material" as const },
  { id: "a4", text: "Aufgabe T-3005 abgeschlossen – Kran-Wartung", project: "Logistikzentrum Nord", time: "gestern", type: "aufgabe" as const },
  { id: "a5", text: "6 neue Fotos hochgeladen", project: "Kita Sonnenschein", time: "gestern", type: "foto" as const },
]

export function formatEuro(value: number): string {
  return new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR", maximumFractionDigits: 0 }).format(value)
}

export function formatDate(iso: string): string {
  return new Intl.DateTimeFormat("de-DE", { day: "2-digit", month: "2-digit", year: "numeric" }).format(new Date(iso))
}
