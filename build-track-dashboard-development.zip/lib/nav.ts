import {
  LayoutDashboard,
  Building2,
  Package,
  TriangleAlert,
  ClipboardCheck,
  ListChecks,
  NotebookPen,
  Images,
  Users,
  type LucideIcon,
} from "lucide-react"

export type NavItem = {
  label: string
  href: string
  icon: LucideIcon
}

export const navItems: NavItem[] = [
  { label: "Dashboard", href: "/", icon: LayoutDashboard },
  { label: "Projekte", href: "/projekte", icon: Building2 },
  { label: "Material & Bestand", href: "/material", icon: Package },
  { label: "Bestandswarnungen", href: "/warnungen", icon: TriangleAlert },
  { label: "Mängel", href: "/maengel", icon: ClipboardCheck },
  { label: "Aufgaben", href: "/aufgaben", icon: ListChecks },
  { label: "Bautagebuch", href: "/berichte", icon: NotebookPen },
  { label: "Fotos", href: "/fotos", icon: Images },
  { label: "Mitarbeiter", href: "/mitarbeiter", icon: Users },
]
