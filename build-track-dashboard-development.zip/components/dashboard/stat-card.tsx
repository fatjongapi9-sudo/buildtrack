import type { LucideIcon } from "lucide-react"
import { Card } from "@/components/ui/card"
import { cn } from "@/lib/utils"

type Accent = "navy" | "teal" | "amber" | "red"

const accentClasses: Record<Accent, string> = {
  navy: "bg-navy/10 text-navy",
  teal: "bg-teal/15 text-teal-700",
  amber: "bg-amber/15 text-amber-700",
  red: "bg-red-100 text-red-600",
}

export function StatCard({
  label,
  value,
  icon: Icon,
  accent = "navy",
  hint,
}: {
  label: string
  value: string | number
  icon: LucideIcon
  accent?: Accent
  hint?: string
}) {
  return (
    <Card className="p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-sm font-medium text-muted-foreground">{label}</p>
          <p className="mt-2 text-2xl font-bold tracking-tight text-navy">{value}</p>
          {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
        </div>
        <span className={cn("flex size-11 shrink-0 items-center justify-center rounded-xl", accentClasses[accent])}>
          <Icon className="size-5" />
        </span>
      </div>
    </Card>
  )
}
