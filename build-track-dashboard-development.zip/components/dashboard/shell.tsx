"use client"

import { useState } from "react"
import { Menu, X, Search, Bell } from "lucide-react"
import { SidebarNav } from "@/components/dashboard/sidebar"
import { BrandMark } from "@/components/brand-logo"

export function DashboardShell({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false)

  return (
    <div className="min-h-svh bg-background">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 lg:block">
        <SidebarNav />
      </aside>

      {/* Mobile drawer */}
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-navy/60 backdrop-blur-sm" onClick={() => setOpen(false)} />
          <div className="absolute inset-y-0 left-0 w-64">
            <SidebarNav onNavigate={() => setOpen(false)} />
            <button
              onClick={() => setOpen(false)}
              className="absolute -right-11 top-4 rounded-md bg-white/10 p-2 text-white"
              aria-label="Menü schließen"
            >
              <X className="size-5" />
            </button>
          </div>
        </div>
      )}

      <div className="lg:pl-64">
        <header className="sticky top-0 z-20 flex h-16 items-center gap-3 border-b border-border bg-card/80 px-4 backdrop-blur-md sm:px-6">
          <button
            onClick={() => setOpen(true)}
            className="rounded-md p-2 text-navy hover:bg-muted lg:hidden"
            aria-label="Menü öffnen"
          >
            <Menu className="size-5" />
          </button>

          <div className="lg:hidden">
            <BrandMark />
          </div>

          <div className="relative hidden max-w-md flex-1 sm:block">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="search"
              placeholder="Suchen nach Projekten, Material, Mängeln..."
              className="h-10 w-full rounded-lg border border-border bg-background pl-9 pr-3 text-sm outline-none transition-colors focus:border-teal focus:ring-2 focus:ring-teal/30"
            />
          </div>

          <div className="ml-auto flex items-center gap-2">
            <button className="relative rounded-lg p-2 text-navy hover:bg-muted" aria-label="Benachrichtigungen">
              <Bell className="size-5" />
              <span className="absolute right-1.5 top-1.5 size-2 rounded-full bg-amber ring-2 ring-card" />
            </button>
            <span className="hidden size-9 items-center justify-center rounded-full bg-navy text-sm font-semibold text-navy-foreground sm:flex">
              AV
            </span>
          </div>
        </header>

        <main className="p-4 sm:p-6">{children}</main>
      </div>
    </div>
  )
}
