import { Badge } from "@/components/ui/badge"

type Tone = "navy" | "teal" | "amber" | "red" | "green" | "gray"

const map: Record<string, { label: string; tone: Tone }> = {
  // project status
  in_arbeit: { label: "In Arbeit", tone: "teal" },
  geplant: { label: "Geplant", tone: "navy" },
  abgeschlossen: { label: "Abgeschlossen", tone: "green" },
  verzoegert: { label: "Verzögert", tone: "amber" },
  // defect / task status
  offen: { label: "Offen", tone: "amber" },
  in_bearbeitung: { label: "In Bearbeitung", tone: "teal" },
  behoben: { label: "Behoben", tone: "green" },
  erledigt: { label: "Erledigt", tone: "green" },
  // severity / priority
  kritisch: { label: "Kritisch", tone: "red" },
  hoch: { label: "Hoch", tone: "red" },
  mittel: { label: "Mittel", tone: "amber" },
  gering: { label: "Gering", tone: "gray" },
  niedrig: { label: "Niedrig", tone: "gray" },
  // employee status
  verfügbar: { label: "Verfügbar", tone: "green" },
  auf_baustelle: { label: "Auf Baustelle", tone: "teal" },
  urlaub: { label: "Urlaub", tone: "navy" },
  krank: { label: "Krank", tone: "red" },
}

export function StatusBadge({ value }: { value: string }) {
  const entry = map[value] ?? { label: value, tone: "gray" as Tone }
  return <Badge tone={entry.tone}>{entry.label}</Badge>
}
