import type * as React from "react"
import { cn } from "@/lib/utils"

type BadgeProps = React.HTMLAttributes<HTMLSpanElement> & {
  tone?: "navy" | "teal" | "amber" | "red" | "green" | "gray"
}

const toneClasses: Record<NonNullable<BadgeProps["tone"]>, string> = {
  navy: "bg-navy/10 text-navy ring-navy/20",
  teal: "bg-teal/15 text-teal-700 ring-teal/30",
  amber: "bg-amber/15 text-amber-700 ring-amber/30",
  red: "bg-red-100 text-red-700 ring-red-200",
  green: "bg-emerald-100 text-emerald-700 ring-emerald-200",
  gray: "bg-muted text-muted-foreground ring-border",
}

export function Badge({ tone = "gray", className, ...props }: BadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset whitespace-nowrap",
        toneClasses[tone],
        className,
      )}
      {...props}
    />
  )
}
