import { cn } from "@/lib/utils"

export function BrandMark({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex size-9 shrink-0 items-center justify-center rounded-lg bg-teal text-teal-foreground",
        className,
      )}
      aria-hidden="true"
    >
      <svg viewBox="0 0 24 24" fill="none" className="size-5" stroke="currentColor" strokeWidth={2.2}>
        <path d="M3 21V9l6-4 6 4v12" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M15 21V13l6-4v12" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M3 21h18" strokeLinecap="round" />
      </svg>
    </span>
  )
}

export function BrandLogo({
  className,
  variant = "light",
}: {
  className?: string
  variant?: "light" | "dark"
}) {
  return (
    <div className={cn("flex items-center gap-2.5", className)}>
      <BrandMark />
      <div className="flex flex-col leading-none">
        <span className={cn("text-lg font-bold tracking-tight", variant === "light" ? "text-white" : "text-navy")}>
          Build<span className="text-teal">Track</span>
        </span>
        <span
          className={cn(
            "text-[10px] font-medium",
            variant === "light" ? "text-white/60" : "text-muted-foreground",
          )}
        >
          Alles im Griff. Auf jeder Baustelle.
        </span>
      </div>
    </div>
  )
}
