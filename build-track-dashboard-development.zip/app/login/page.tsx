import Link from "next/link"
import { Mail, Lock, ArrowRight, ShieldCheck, HardHat, ClipboardCheck } from "lucide-react"
import { BrandLogo } from "@/components/brand-logo"

export default function LoginPage() {
  return (
    <div className="grid min-h-svh lg:grid-cols-2">
      {/* Brand panel */}
      <div className="relative hidden flex-col justify-between overflow-hidden bg-sidebar p-10 text-white lg:flex">
        <div className="absolute inset-0 opacity-10" aria-hidden="true">
          <div className="absolute -right-16 -top-16 size-80 rounded-full bg-teal" />
          <div className="absolute -bottom-24 -left-10 size-96 rounded-full bg-teal/50" />
        </div>

        <div className="relative">
          <BrandLogo variant="light" />
        </div>

        <div className="relative space-y-6">
          <h2 className="text-3xl font-bold leading-tight">
            Alles im Griff.<br />
            <span className="text-teal">Auf jeder Baustelle.</span>
          </h2>
          <p className="max-w-md text-white/70">
            Projekte, Material, Mängel und Berichte – die zentrale Plattform für das digitale Baustellenmanagement Ihres Bauunternehmens.
          </p>
          <ul className="space-y-3 text-sm text-white/80">
            <li className="flex items-center gap-3">
              <span className="flex size-8 items-center justify-center rounded-lg bg-white/10"><HardHat className="size-4 text-teal" /></span>
              Zentrale Verwaltung aller Bauprojekte
            </li>
            <li className="flex items-center gap-3">
              <span className="flex size-8 items-center justify-center rounded-lg bg-white/10"><ClipboardCheck className="size-4 text-teal" /></span>
              Mängel und Aufgaben nachverfolgen
            </li>
            <li className="flex items-center gap-3">
              <span className="flex size-8 items-center justify-center rounded-lg bg-white/10"><ShieldCheck className="size-4 text-teal" /></span>
              Bestände und Warnungen im Blick
            </li>
          </ul>
        </div>

        <p className="relative text-xs text-white/40">© 2026 BuildTrack GmbH · Alle Rechte vorbehalten</p>
      </div>

      {/* Form panel */}
      <div className="flex items-center justify-center bg-background p-6 sm:p-10">
        <div className="w-full max-w-sm">
          <div className="mb-8 lg:hidden">
            <BrandLogo variant="dark" />
          </div>

          <div className="mb-8">
            <h1 className="text-2xl font-bold tracking-tight text-navy">Anmelden</h1>
            <p className="mt-1 text-sm text-muted-foreground">Willkommen zurück. Bitte melden Sie sich an.</p>
          </div>

          <form className="space-y-4">
            <div>
              <label htmlFor="email" className="mb-1.5 block text-sm font-medium text-foreground">
                E-Mail-Adresse
              </label>
              <div className="relative">
                <Mail className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  id="email"
                  type="email"
                  defaultValue="a.vogel@buildtrack.de"
                  placeholder="name@firma.de"
                  className="h-11 w-full rounded-lg border border-border bg-card pl-9 pr-3 text-sm outline-none transition-colors focus:border-teal focus:ring-2 focus:ring-teal/30"
                />
              </div>
            </div>

            <div>
              <div className="mb-1.5 flex items-center justify-between">
                <label htmlFor="password" className="block text-sm font-medium text-foreground">
                  Passwort
                </label>
                <a href="#" className="text-xs font-medium text-teal-700 hover:underline">Passwort vergessen?</a>
              </div>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  id="password"
                  type="password"
                  defaultValue="passwort"
                  placeholder="••••••••"
                  className="h-11 w-full rounded-lg border border-border bg-card pl-9 pr-3 text-sm outline-none transition-colors focus:border-teal focus:ring-2 focus:ring-teal/30"
                />
              </div>
            </div>

            <label className="flex items-center gap-2 text-sm text-muted-foreground">
              <input type="checkbox" defaultChecked className="size-4 rounded border-border text-teal accent-teal" />
              Angemeldet bleiben
            </label>

            <Link
              href="/"
              className="flex h-11 w-full items-center justify-center gap-2 rounded-lg bg-navy text-sm font-semibold text-navy-foreground transition-colors hover:bg-navy/90"
            >
              Anmelden <ArrowRight className="size-4" />
            </Link>
          </form>

          <p className="mt-6 text-center text-sm text-muted-foreground">
            Noch kein Konto?{" "}
            <a href="#" className="font-medium text-teal-700 hover:underline">Zugang anfordern</a>
          </p>
        </div>
      </div>
    </div>
  )
}
