import Link from "next/link"
import { Building2, TriangleAlert, ClipboardCheck, Users, ArrowRight, ClipboardList, Package, NotebookPen, Image as ImageIcon } from "lucide-react"
import { PageHeader } from "@/components/dashboard/page-header"
import { StatCard } from "@/components/dashboard/stat-card"
import { StatusBadge } from "@/components/dashboard/status"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import {
  kpis,
  projects,
  defects,
  lowStockMaterials,
  activityFeed,
  formatEuro,
  formatDate,
} from "@/lib/data"

const activityIcon = {
  mangel: ClipboardCheck,
  bericht: NotebookPen,
  material: Package,
  aufgabe: ClipboardList,
  foto: ImageIcon,
}

export default function DashboardPage() {
  const budgetPct = Math.round((kpis.totalSpent / kpis.totalBudget) * 100)
  const activeProjects = projects.filter((p) => p.status === "in_arbeit")
  const openDefects = defects.filter((d) => d.status !== "behoben").slice(0, 4)

  return (
    <>
      <PageHeader
        title="Dashboard"
        description="Willkommen zurück, Andreas – hier ist der Überblick über alle Baustellen."
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Aktive Projekte" value={kpis.activeProjects} icon={Building2} accent="navy" hint="von insgesamt 6" />
        <StatCard label="Offene Mängel" value={kpis.openDefects} icon={ClipboardCheck} accent="red" hint="2 kritisch" />
        <StatCard label="Bestandswarnungen" value={kpis.lowStock} icon={TriangleAlert} accent="amber" hint="Material unter Mindestbestand" />
        <StatCard label="Mitarbeiter heute" value={kpis.workersToday} icon={Users} accent="teal" hint="auf allen Baustellen" />
      </div>

      <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Budget */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Budgetübersicht</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex items-end justify-between">
                <span className="text-sm text-muted-foreground">Ausgegeben</span>
                <span className="text-lg font-bold text-navy">{formatEuro(kpis.totalSpent)}</span>
              </div>
              <Progress value={budgetPct} className="mt-2 h-3" />
              <div className="mt-1.5 flex justify-between text-xs text-muted-foreground">
                <span>{budgetPct}% des Budgets</span>
                <span>{formatEuro(kpis.totalBudget)} gesamt</span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 border-t border-border pt-4">
              <div>
                <p className="text-xs text-muted-foreground">Verbleibend</p>
                <p className="text-base font-semibold text-teal-700">{formatEuro(kpis.totalBudget - kpis.totalSpent)}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Offene Aufgaben</p>
                <p className="text-base font-semibold text-navy">{kpis.openTasks}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Active projects */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex-row items-center justify-between">
            <CardTitle>Laufende Projekte</CardTitle>
            <Link href="/projekte" className="flex items-center gap-1 text-sm font-medium text-teal-700 hover:underline">
              Alle anzeigen <ArrowRight className="size-3.5" />
            </Link>
          </CardHeader>
          <CardContent className="space-y-4">
            {activeProjects.map((p) => (
              <div key={p.id} className="space-y-2">
                <div className="flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold text-navy">{p.name}</p>
                    <p className="truncate text-xs text-muted-foreground">{p.location} · {p.manager}</p>
                  </div>
                  <span className="shrink-0 text-sm font-semibold text-navy">{p.progress}%</span>
                </div>
                <Progress value={p.progress} />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Recent defects */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex-row items-center justify-between">
            <CardTitle>Aktuelle Mängel</CardTitle>
            <Link href="/maengel" className="flex items-center gap-1 text-sm font-medium text-teal-700 hover:underline">
              Alle anzeigen <ArrowRight className="size-3.5" />
            </Link>
          </CardHeader>
          <CardContent className="space-y-1">
            {openDefects.map((d) => (
              <div key={d.id} className="flex items-center justify-between gap-3 rounded-lg px-2 py-2.5 hover:bg-muted/60">
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium text-navy">{d.title}</p>
                  <p className="truncate text-xs text-muted-foreground">{d.project} · fällig {formatDate(d.dueDate)}</p>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <StatusBadge value={d.severity} />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Activity */}
        <Card>
          <CardHeader>
            <CardTitle>Aktivität</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {activityFeed.map((a) => {
              const Icon = activityIcon[a.type]
              return (
                <div key={a.id} className="flex gap-3">
                  <span className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-lg bg-muted text-navy">
                    <Icon className="size-4" />
                  </span>
                  <div className="min-w-0">
                    <p className="text-sm leading-snug text-foreground">{a.text}</p>
                    <p className="text-xs text-muted-foreground">{a.project} · {a.time}</p>
                  </div>
                </div>
              )
            })}
          </CardContent>
        </Card>
      </div>

      {/* Low stock quick strip */}
      <Card className="mt-4">
        <CardHeader className="flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <TriangleAlert className="size-4 text-amber-600" /> Niedrige Bestände
          </CardTitle>
          <Link href="/warnungen" className="flex items-center gap-1 text-sm font-medium text-teal-700 hover:underline">
            Alle anzeigen <ArrowRight className="size-3.5" />
          </Link>
        </CardHeader>
        <CardContent className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {lowStockMaterials.map((m) => (
            <div key={m.id} className="rounded-lg border border-amber/30 bg-amber/5 p-3">
              <p className="text-sm font-semibold text-navy">{m.name}</p>
              <p className="mt-1 text-xs text-muted-foreground">{m.location}</p>
              <p className="mt-2 text-xs">
                <span className="font-semibold text-amber-700">{m.stock} {m.unit}</span>
                <span className="text-muted-foreground"> / Min. {m.minStock} {m.unit}</span>
              </p>
            </div>
          ))}
        </CardContent>
      </Card>
    </>
  )
}
