import Image from "next/image"
import { Upload, User } from "lucide-react"
import { PageHeader } from "@/components/dashboard/page-header"
import { Badge } from "@/components/ui/badge"
import { photos, formatDate } from "@/lib/data"

export default function FotosPage() {
  return (
    <>
      <PageHeader
        title="Fotos"
        description="Baustellendokumentation und Fortschrittsfotos"
        action={
          <button className="inline-flex items-center gap-2 rounded-lg bg-navy px-3.5 py-2 text-sm font-medium text-navy-foreground transition-colors hover:bg-navy/90">
            <Upload className="size-4" /> Foto hochladen
          </button>
        }
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {photos.map((photo) => (
          <div key={photo.id} className="group overflow-hidden rounded-xl border border-border bg-card">
            <div className="relative aspect-[4/3] overflow-hidden bg-muted">
              <Image
                src={photo.src || "/placeholder.svg"}
                alt={photo.title}
                fill
                sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                className="object-cover transition-transform duration-300 group-hover:scale-105"
              />
              <div className="absolute left-2 top-2">
                <Badge tone="navy" className="bg-navy/80 text-white ring-white/20 backdrop-blur-sm">
                  {photo.project}
                </Badge>
              </div>
            </div>
            <div className="p-4">
              <h3 className="text-sm font-semibold text-navy">{photo.title}</h3>
              <div className="mt-1 flex items-center justify-between text-xs text-muted-foreground">
                <span className="flex items-center gap-1.5">
                  <User className="size-3.5" /> {photo.author}
                </span>
                <span>{formatDate(photo.date)}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  )
}
