import { TriangleAlert, ShoppingCart } from "lucide-react"
import { PageHeader } from "@/components/dashboard/page-header"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { lowStockMaterials, formatEuro } from "@/lib/data"

export default function WarnungenPage() {
  return (
    <>
      <PageHeader
        title="Bestandswarnungen"
        description={`${lowStockMaterials.length} Materialien haben den Mindestbestand unterschritten`}
      />

      <div className="mb-4 flex items-start gap-3 rounded-xl border border-amber/30 bg-amber/10 p-4">
        <TriangleAlert className="mt-0.5 size-5 shrink-0 text-amber-600" />
        <div>
          <p className="text-sm font-semibold text-navy">Nachbestellung empfohlen</p>
          <p className="text-sm text-muted-foreground">
            Die folgenden Artikel sollten zeitnah nachbestellt werden, um Verzögerungen auf den Baustellen zu vermeiden.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {lowStockMaterials.map((m) => {
          const pct = Math.round((m.stock / m.minStock) * 100)
          const reorder = Math.max(m.minStock - m.stock, 0)
          return (
            <Card key={m.id}>
              <CardContent className="p-5">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="text-base font-semibold text-navy">{m.name}</h3>
                    <p className="text-xs text-muted-foreground">{m.id} · {m.category} · {m.location}</p>
                  </div>
                  <span className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-amber/15 text-amber-700">
                    <TriangleAlert className="size-4" />
                  </span>
                </div>

                <div className="mt-4">
                  <div className="mb-1.5 flex justify-between text-xs">
                    <span className="text-muted-foreground">Bestand</span>
                    <span className="font-semibold text-amber-700">{m.stock} / {m.minStock} {m.unit}</span>
                  </div>
                  <Progress value={pct} barClassName="bg-amber" />
                </div>

                <div className="mt-4 flex items-center justify-between border-t border-border pt-4">
                  <div className="text-sm">
                    <p className="text-xs text-muted-foreground">Empfohlene Nachbestellung</p>
                    <p className="font-semibold text-navy">
                      {reorder} {m.unit} · ca. {formatEuro(reorder * m.price)}
                    </p>
                  </div>
                  <button className="inline-flex items-center gap-2 rounded-lg bg-teal px-3 py-2 text-sm font-medium text-teal-foreground transition-colors hover:bg-teal/90">
                    <ShoppingCart className="size-4" /> Bestellen
                  </button>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </>
  )
}
