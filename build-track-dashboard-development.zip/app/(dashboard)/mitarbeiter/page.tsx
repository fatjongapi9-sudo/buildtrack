import { Plus, Phone, Mail } from "lucide-react"
import { PageHeader } from "@/components/dashboard/page-header"
import { StatusBadge } from "@/components/dashboard/status"
import { StatCard } from "@/components/dashboard/stat-card"
import { Card, CardContent } from "@/components/ui/card"
import { Users, HardHat } from "lucide-react"
import { employees } from "@/lib/data"

function initials(name: string) {
  return name.split(" ").map((n) => n[0]).slice(0, 2).join("")
}

export default function MitarbeiterPage() {
  const onSite = employees.filter((e) => e.status === "auf_baustelle").length
  const available = employees.filter((e) => e.status === "verfügbar").length

  return (
    <>
      <PageHeader
        title="Mitarbeiter"
        description={`${employees.length} Mitarbeiter im Team`}
        action={
          <button className="inline-flex items-center gap-2 rounded-lg bg-navy px-3.5 py-2 text-sm font-medium text-navy-foreground transition-colors hover:bg-navy/90">
            <Plus className="size-4" /> Mitarbeiter hinzufügen
          </button>
        }
      />

      <div className="mb-4 grid grid-cols-3 gap-4">
        <StatCard label="Gesamt" value={employees.length} icon={Users} accent="navy" />
        <StatCard label="Auf Baustelle" value={onSite} icon={HardHat} accent="teal" />
        <StatCard label="Verfügbar" value={available} icon={Users} accent="amber" />
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {employees.map((e) => (
          <Card key={e.id}>
            <CardContent className="p-5">
              <div className="flex items-start gap-3">
                <span className="flex size-12 shrink-0 items-center justify-center rounded-full bg-navy text-base font-semibold text-navy-foreground">
                  {initials(e.name)}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <h3 className="truncate text-base font-semibold text-navy">{e.name}</h3>
                      <p className="text-sm text-muted-foreground">{e.role} · {e.team}</p>
                    </div>
                    <StatusBadge value={e.status} />
                  </div>
                </div>
              </div>

              <div className="mt-4 space-y-1.5 border-t border-border pt-4 text-sm text-muted-foreground">
                <p className="flex items-center gap-2">
                  <Phone className="size-4 shrink-0 text-teal-700" /> {e.phone}
                </p>
                <p className="flex items-center gap-2">
                  <Mail className="size-4 shrink-0 text-teal-700" /> <span className="truncate">{e.email}</span>
                </p>
                <p className="pt-1 text-xs">
                  <span className="text-muted-foreground">Aktuelles Projekt: </span>
                  <span className="font-medium text-foreground">{e.project}</span>
                </p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </>
  )
}
