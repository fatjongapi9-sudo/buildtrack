import { Plus, Package, TriangleAlert } from "lucide-react"
import { PageHeader } from "@/components/dashboard/page-header"
import { Badge } from "@/components/ui/badge"
import { StatCard } from "@/components/dashboard/stat-card"
import { TableWrap, THead, TH, TR, TD } from "@/components/ui/table"
import { materials, lowStockMaterials, formatEuro } from "@/lib/data"

export default function MaterialPage() {
  const totalValue = materials.reduce((s, m) => s + m.stock * m.price, 0)

  return (
    <>
      <PageHeader
        title="Material & Bestand"
        description="Bestandsverwaltung über alle Lager und Baustellen"
        action={
          <button className="inline-flex items-center gap-2 rounded-lg bg-navy px-3.5 py-2 text-sm font-medium text-navy-foreground transition-colors hover:bg-navy/90">
            <Plus className="size-4" /> Material anlegen
          </button>
        }
      />

      <div className="mb-4 grid grid-cols-2 gap-4 lg:grid-cols-3">
        <StatCard label="Artikel gesamt" value={materials.length} icon={Package} accent="navy" />
        <StatCard label="Bestandswert" value={formatEuro(totalValue)} icon={Package} accent="teal" />
        <StatCard label="Unter Mindestbestand" value={lowStockMaterials.length} icon={TriangleAlert} accent="amber" />
      </div>

      <TableWrap>
        <THead>
          <tr>
            <TH>Artikel</TH>
            <TH>Kategorie</TH>
            <TH>Bestand</TH>
            <TH>Mindest</TH>
            <TH>Preis / Einheit</TH>
            <TH>Lieferant</TH>
            <TH>Standort</TH>
          </tr>
        </THead>
        <tbody>
          {materials.map((m) => {
            const low = m.stock < m.minStock
            return (
              <TR key={m.id}>
                <TD>
                  <div className="font-medium text-navy">{m.name}</div>
                  <div className="text-xs text-muted-foreground">{m.id}</div>
                </TD>
                <TD className="text-muted-foreground">{m.category}</TD>
                <TD>
                  <span className={low ? "font-semibold text-amber-700" : "font-medium text-navy"}>
                    {m.stock} {m.unit}
                  </span>
                  {low && (
                    <Badge tone="amber" className="ml-2">
                      <TriangleAlert className="size-3" /> Niedrig
                    </Badge>
                  )}
                </TD>
                <TD className="text-muted-foreground">{m.minStock} {m.unit}</TD>
                <TD className="text-foreground">{formatEuro(m.price)}</TD>
                <TD className="text-muted-foreground">{m.supplier}</TD>
                <TD className="text-muted-foreground">{m.location}</TD>
              </TR>
            )
          })}
        </tbody>
      </TableWrap>
    </>
  )
}
