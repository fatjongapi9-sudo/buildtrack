import { Plus, MapPin, User } from "lucide-react"
import { PageHeader } from "@/components/dashboard/page-header"
import { StatusBadge } from "@/components/dashboard/status"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { projects, formatEuro, formatDate } from "@/lib/data"

export default function ProjektePage() {
  return (
    <>
      <PageHeader
        title="Projekte"
        description={`${projects.length} Bauprojekte insgesamt`}
        action={
          <button className="inline-flex items-center gap-2 rounded-lg bg-navy px-3.5 py-2 text-sm font-medium text-navy-foreground transition-colors hover:bg-navy/90">
            <Plus className="size-4" /> Neues Projekt
          </button>
        }
      />

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
        {projects.map((p) => (
          <Card key={p.id} className="flex flex-col">
            <CardContent className="flex flex-1 flex-col gap-4 p-5">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-xs font-medium text-muted-foreground">{p.id}</p>
                  <h3 className="mt-0.5 text-base font-semibold leading-tight text-navy">{p.name}</h3>
                </div>
                <StatusBadge value={p.status} />
              </div>

              <div className="space-y-1.5 text-sm text-muted-foreground">
                <p className="flex items-center gap-2">
                  <MapPin className="size-4 shrink-0 text-teal-700" /> {p.location}
                </p>
                <p className="flex items-center gap-2">
                  <User className="size-4 shrink-0 text-teal-700" /> {p.manager}
                </p>
              </div>

              <div>
                <div className="mb-1.5 flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Fortschritt</span>
                  <span className="font-semibold text-navy">{p.progress}%</span>
                </div>
                <Progress value={p.progress} />
              </div>

              <div className="mt-auto grid grid-cols-2 gap-3 border-t border-border pt-4 text-sm">
                <div>
                  <p className="text-xs text-muted-foreground">Budget</p>
                  <p className="font-semibold text-navy">{formatEuro(p.budget)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Ausgegeben</p>
                  <p className="font-semibold text-navy">{formatEuro(p.spent)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Beginn</p>
                  <p className="font-medium text-foreground">{formatDate(p.start)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Fertigstellung</p>
                  <p className="font-medium text-foreground">{formatDate(p.end)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </>
  )
}
