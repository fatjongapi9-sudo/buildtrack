import { Plus, CloudSun, Users, Clock, User } from "lucide-react"
import { PageHeader } from "@/components/dashboard/page-header"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { dailyReports, formatDate } from "@/lib/data"

export default function BerichtePage() {
  return (
    <>
      <PageHeader
        title="Bautagebuch"
        description="Tägliche Bauberichte von allen Baustellen"
        action={
          <button className="inline-flex items-center gap-2 rounded-lg bg-navy px-3.5 py-2 text-sm font-medium text-navy-foreground transition-colors hover:bg-navy/90">
            <Plus className="size-4" /> Neuer Bericht
          </button>
        }
      />

      <div className="space-y-4">
        {dailyReports.map((r) => (
          <Card key={r.id}>
            <CardContent className="p-5">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-semibold text-navy">{r.project}</h3>
                    <Badge tone="navy">{formatDate(r.date)}</Badge>
                  </div>
                  <p className="mt-0.5 flex items-center gap-1.5 text-xs text-muted-foreground">
                    <User className="size-3.5" /> {r.author} · Bericht {r.id}
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-4 text-sm">
                  <span className="flex items-center gap-1.5 text-muted-foreground">
                    <CloudSun className="size-4 text-amber-600" /> {r.weather}, {r.temperature}°C
                  </span>
                  <span className="flex items-center gap-1.5 text-muted-foreground">
                    <Users className="size-4 text-teal-700" /> {r.workers} MA
                  </span>
                  <span className="flex items-center gap-1.5 text-muted-foreground">
                    <Clock className="size-4 text-navy" /> {r.hours} Std.
                  </span>
                </div>
              </div>
              <p className="mt-3 border-t border-border pt-3 text-sm leading-relaxed text-foreground">{r.summary}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </>
  )
}
