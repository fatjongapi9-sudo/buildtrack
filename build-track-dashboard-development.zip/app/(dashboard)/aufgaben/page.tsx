import { Plus, Calendar, User } from "lucide-react"
import { PageHeader } from "@/components/dashboard/page-header"
import { StatusBadge } from "@/components/dashboard/status"
import { Card } from "@/components/ui/card"
import { tasks, formatDate, type Task } from "@/lib/data"

const columns: { key: Task["status"]; label: string; dot: string }[] = [
  { key: "offen", label: "Offen", dot: "bg-amber" },
  { key: "in_arbeit", label: "In Arbeit", dot: "bg-teal" },
  { key: "erledigt", label: "Erledigt", dot: "bg-emerald-500" },
]

export default function AufgabenPage() {
  return (
    <>
      <PageHeader
        title="Aufgaben"
        description="Aufgaben und To-dos über alle Projekte"
        action={
          <button className="inline-flex items-center gap-2 rounded-lg bg-navy px-3.5 py-2 text-sm font-medium text-navy-foreground transition-colors hover:bg-navy/90">
            <Plus className="size-4" /> Neue Aufgabe
          </button>
        }
      />

      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        {columns.map((col) => {
          const items = tasks.filter((t) => t.status === col.key)
          return (
            <div key={col.key} className="flex flex-col gap-3">
              <div className="flex items-center gap-2 px-1">
                <span className={`size-2.5 rounded-full ${col.dot}`} />
                <h2 className="text-sm font-semibold text-navy">{col.label}</h2>
                <span className="rounded-full bg-muted px-2 py-0.5 text-xs font-medium text-muted-foreground">
                  {items.length}
                </span>
              </div>

              <div className="flex flex-col gap-3">
                {items.map((t) => (
                  <Card key={t.id} className="p-4">
                    <div className="flex items-start justify-between gap-2">
                      <p className="text-sm font-semibold text-navy">{t.title}</p>
                      <StatusBadge value={t.priority} />
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">{t.project}</p>
                    <div className="mt-3 flex items-center justify-between border-t border-border pt-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1.5">
                        <User className="size-3.5" /> {t.assignee}
                      </span>
                      <span className="flex items-center gap-1.5">
                        <Calendar className="size-3.5" /> {formatDate(t.dueDate)}
                      </span>
                    </div>
                  </Card>
                ))}
                {items.length === 0 && (
                  <p className="rounded-lg border border-dashed border-border py-6 text-center text-xs text-muted-foreground">
                    Keine Aufgaben
                  </p>
                )}
              </div>
            </div>
          )
        })}
      </div>
    </>
  )
}
