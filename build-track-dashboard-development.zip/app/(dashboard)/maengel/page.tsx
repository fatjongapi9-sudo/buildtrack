import { Plus, ClipboardCheck } from "lucide-react"
import { PageHeader } from "@/components/dashboard/page-header"
import { StatusBadge } from "@/components/dashboard/status"
import { StatCard } from "@/components/dashboard/stat-card"
import { TableWrap, THead, TH, TR, TD } from "@/components/ui/table"
import { defects, formatDate } from "@/lib/data"

export default function MaengelPage() {
  const open = defects.filter((d) => d.status === "offen").length
  const inProgress = defects.filter((d) => d.status === "in_bearbeitung").length
  const critical = defects.filter((d) => d.severity === "kritisch" && d.status !== "behoben").length

  return (
    <>
      <PageHeader
        title="Mängel"
        description="Erfassung und Nachverfolgung von Baumängeln"
        action={
          <button className="inline-flex items-center gap-2 rounded-lg bg-navy px-3.5 py-2 text-sm font-medium text-navy-foreground transition-colors hover:bg-navy/90">
            <Plus className="size-4" /> Mangel melden
          </button>
        }
      />

      <div className="mb-4 grid grid-cols-3 gap-4">
        <StatCard label="Offen" value={open} icon={ClipboardCheck} accent="amber" />
        <StatCard label="In Bearbeitung" value={inProgress} icon={ClipboardCheck} accent="teal" />
        <StatCard label="Kritisch" value={critical} icon={ClipboardCheck} accent="red" />
      </div>

      <TableWrap>
        <THead>
          <tr>
            <TH>Mangel</TH>
            <TH>Projekt</TH>
            <TH>Gewerk</TH>
            <TH>Schwere</TH>
            <TH>Status</TH>
            <TH>Gemeldet von</TH>
            <TH>Fällig</TH>
          </tr>
        </THead>
        <tbody>
          {defects.map((d) => (
            <TR key={d.id}>
              <TD>
                <div className="font-medium text-navy">{d.title}</div>
                <div className="text-xs text-muted-foreground">{d.id} · {formatDate(d.reportedAt)}</div>
              </TD>
              <TD className="text-muted-foreground">{d.project}</TD>
              <TD className="text-muted-foreground">{d.trade}</TD>
              <TD><StatusBadge value={d.severity} /></TD>
              <TD><StatusBadge value={d.status} /></TD>
              <TD className="text-muted-foreground">{d.reportedBy}</TD>
              <TD className="text-foreground">{formatDate(d.dueDate)}</TD>
            </TR>
          ))}
        </tbody>
      </TableWrap>
    </>
  )
}
